/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam;

/**
 *
 * @author KOSTA
 */
public class RandomValue {
     ServiceCook sc;
     
        
        double randomValue = Math.random();
          int intValue = (int)(randomValue * 10)%3+1;    
    
    
}
