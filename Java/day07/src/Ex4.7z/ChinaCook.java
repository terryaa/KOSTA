package Ex4;

public class ChinaCook extends Cook implements ServiceCook{
	public String Food() {
		return "�߱�����";
	}
}
